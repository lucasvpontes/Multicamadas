package br.usjt.veiculos.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import br.usjt.veiculos.model.bean.Veiculo;
import br.usjt.veiculos.model.repository.VeiculoRepository;

@Controller
public class VeiculoController {
	@Autowired
	private VeiculoRepository veiculosRepo;
	
	@GetMapping("/veiculos")
	public ModelAndView listarVeiculos() {
		ModelAndView mv = new ModelAndView("lista_veiculos");
		List<Veiculo> veiculos = veiculosRepo.findAll();
		mv.addObject("veiculos", veiculos);
		return mv;
	}
}
